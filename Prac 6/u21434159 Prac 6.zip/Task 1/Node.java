public class Node<T> {
    T value;

    Node(T val) {
        value = val;
    }
}
